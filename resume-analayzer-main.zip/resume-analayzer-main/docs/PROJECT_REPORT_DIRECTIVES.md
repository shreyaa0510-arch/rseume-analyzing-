# Project Report Requirements and Directives

Use this file as the source of truth when creating a college-style major project report for any codebase. It captures the structure, table of contents, formatting rhythm, and content expectations of the reference report without requiring the original sample PDF.

## 1. Report Purpose

Create a formal academic major project report that explains a software project from problem statement through design, implementation, results, screenshots, conclusion, limitations, future enhancement, and bibliography.

The report should be understandable to evaluators who have not seen the codebase. It must describe what the system does, why it is needed, how it is built, which technologies are used, how it was tested, and what results were achieved.

## 1.1 Agent Operating Protocol

An agent using this file must treat it as an execution playbook, not just a style guide. The agent must read the target codebase first, build an evidence map, and then write the report from verified project facts.

Required workflow:

1. Read this directives file completely.
2. Identify the target project root and output location.
3. Inventory the codebase using file search.
4. Read project metadata and setup files.
5. Read backend/server code.
6. Read frontend/client code.
7. Read database/schema/storage code.
8. Read API integration, AI/ML, authentication, deployment, and testing files.
9. Build a source-backed project fact sheet.
10. Draft the report chapter by chapter using the required table of contents.
11. Generate a DOCX file with Word styles, page breaks, section breaks, captions, and real tables.
12. Render/inspect the DOCX when tooling is available.
13. Fix layout or factual issues.
14. Deliver the final DOCX and mention any missing inputs or verification limits.

The agent must not begin writing long report prose until it has inspected the codebase enough to identify the real architecture, modules, dependencies, and limitations.

## 1.2 Source-of-Truth Hierarchy

When sources disagree, use this priority order:

1. Actual source code and configuration files.
2. Package/dependency manifests.
3. Deployment/build files.
4. Existing project documentation.
5. User-provided project details.
6. Reasonable inference, clearly marked internally before being converted into prose.

Do not copy outdated documentation if the source code contradicts it. For example, if documentation says an endpoint calls an absolute URL but the frontend source uses a relative path, describe the implementation shown in source code.

## 1.3 Evidence Map Requirement

Before writing the DOCX, create an internal evidence map with this structure:

```text
Project name:
Project category:
Primary users:
Problem solved:
Frontend files and technologies:
Backend files and technologies:
Database/storage files and technologies:
AI/ML/NLP logic:
Authentication/security:
API endpoints:
Core modules:
Inputs:
Outputs:
Deployment:
Testing evidence:
Known limitations:
Screenshots needed:
Bibliography sources:
```

Use this evidence map to prevent invented features. If a field is not present in the codebase, write "Not implemented" or "Not found" internally and decide whether it belongs in Limitations or Future Enhancement.

## 1.4 Codebase Reading Checklist

An agent must inspect these file categories where present:

| Category | Files/Signals to Inspect | What to Extract |
| --- | --- | --- |
| Project overview | `README`, `docs/*`, repository name | Title, purpose, features, setup notes |
| Dependencies | `requirements.txt`, `package.json`, `pyproject.toml`, lockfiles | Real technology stack |
| Backend | Routes, controllers, services, models, utilities | APIs, business logic, validation, errors |
| Frontend | Pages, components, scripts, styles | Screens, user workflow, UI behavior |
| Data layer | Models, schemas, migrations, JSON files, local storage use | Entities, storage strategy, data flow |
| AI/ML logic | Model files, prompts, NLP code, vectorizers, API clients | Intelligence method, inputs, outputs, limitations |
| Authentication | Auth routes, JWT/session code, password hashing | Login model and security features |
| External APIs | API clients, env vars, SDK usage | Integration purpose and failure modes |
| Deployment | `Dockerfile`, `render.yaml`, CI, build scripts | Hosting target, build/start commands |
| Testing | Test folders, scripts, manual docs | Test coverage and gaps |
| Generated assets | `artifacts`, screenshots, reports | Existing deliverables or reusable visuals |

If the project has no database, no authentication, no test suite, or no deployed environment, the report must say so carefully in the appropriate chapters instead of pretending those parts exist.

## 2. Required Inputs Before Writing

Collect these details before drafting the report:

- Project title.
- College/institute name.
- Department name.
- University name.
- Degree/program name.
- Academic session.
- Student names and enrollment numbers.
- Guide/supervisor name and designation.
- HOD name and designation.
- Director/principal name and designation.
- Project category, such as web application, AI application, mobile app, data science system, IoT system, or full-stack application.
- Core technology stack.
- Main modules/features.
- Database/storage design.
- Deployment target, if any.
- Screenshots of main pages/workflows.
- References/APIs/libraries used.

When generating the report from a codebase, inspect at least:

- `README` and setup files.
- Package manifests such as `package.json`, `requirements.txt`, `pyproject.toml`, `pom.xml`, or similar.
- Backend routes/controllers/services.
- Database models/schemas/migrations.
- Frontend pages/components.
- Authentication and API integration code.
- Deployment files such as `render.yaml`, `Dockerfile`, CI files, or environment examples.
- Test files, scripts, and documented manual testing steps.

## 3. Overall Report Order

The report must follow this order:

1. Cover page.
2. Certificate page.
3. Acknowledgement page.
4. Group members and personal contribution page.
5. Index/table of contents page.
6. Numbered body chapters, starting with body page number 1.
7. Bibliography as the final chapter.

Front matter pages should not be counted in the body page numbers. In the reference format, the Introduction begins at body page 1 even though it appears after the front matter and index.

## 4. Front Matter Requirements

### 4.1 Cover Page

Include:

- College/institute name at the top.
- Location/campus name, if applicable.
- "MAJOR PROJECT REPORT".
- Project title in quotes or clear display text.
- Submission line: "Submitted in partial fulfillment of Bachelor of Technology Degree in [Branch/Department]".
- University name.
- "Submitted By:" followed by student names and enrollment numbers.
- Academic session.

### 4.2 Certificate Page

Include:

- College/institute name.
- Department name.
- "CERTIFICATE" heading.
- Certification paragraph stating that the project report is a bona fide work completed under supervision and submitted for partial fulfillment of the degree.
- Approval/signature area for HOD, guide/supervisor, and director/principal.

### 4.3 Acknowledgement Page

Write in first-person plural if it is a group project. Thank:

- Director/principal.
- HOD.
- Guide/supervisor.
- Faculty members.
- Lab/technical support, if relevant.
- Parents/family and others who supported the work.

End with group member names.

### 4.4 Group Members and Contribution Page

Include:

- Project title.
- "OUR GROUP MEMBERS:" list with names and enrollment numbers.
- "PERSONAL CONTRIBUTION IN THE PROJECT:" section.
- One paragraph per student, describing realistic contributions such as frontend development, backend development, database design, AI/API integration, testing, documentation, deployment, coordination, or presentation preparation.

## 5. Table of Contents / Index

Use the heading "INDEX".

The index should list only the major chapters, not every subsection. Use three columns:

| S. No. | Contents | Page No. |
| --- | --- | --- |
| 1. | INTRODUCTION | 1-6 |
| 2. | SYSTEM REQUIREMENTS | 7-13 |
| 3. | SYSTEM DESIGN | 14-24 |
| 4. | SOFTWARE MODEL | 25-29 |
| 5. | TOOLS AND TECHNOLOGIES | 30-34 |
| 6. | IMPLEMENTATION | 35-38 |
| 7. | RESULTS | 39-47 |
| 8. | SNAPSHOTS | 48-51 |
| 9. | CONCLUSION | 52 |
| 10. | LIMITATIONS | 53 |
| 11. | FUTURE ENHANCEMENT | 54 |
| 12. | BIBLIOGRAPHY | 55 |

Directives:

- Keep this chapter order for similar reports.
- Update page ranges after the final document is laid out.
- Use body page numbers, not PDF page numbers.
- If the report becomes longer or shorter, preserve the same order and adjust page ranges.
- Prefer "SYSTEM REQUIREMENTS" and "SOFTWARE MODEL" spellings consistently, even if an older sample has minor spelling or spacing mistakes.
- Single-page final chapters can use one page number instead of a range.

## 6. Body Chapter Structure

Use numbered chapter headings in this style:

- `1. INTRODUCTION`
- `1.1 Introduction to Project`
- `1.2 Project Category`

Major chapter headings should be uppercase. Subsection headings should use title case. Use formal academic language and avoid casual wording.

### 6.1 Chapter 1: Introduction

Target length: about 6 body pages.

Required subsections:

- `1.1 Introduction to Project`
- `1.2 Project Category`
- `1.3 Objectives`
- `1.4 Problem Formulation`
- `1.5 Identification of Need`
- `1.6 Existing System`
- `1.7 Proposed System`
- `1.7.1 Unique Features of the System`

Content directives:

- Explain the domain and real-world problem.
- Introduce the project title and core idea.
- Describe why the system is needed.
- State the project category.
- Provide clear objectives as bullet points.
- Compare the existing/manual system with the proposed system.
- Mention unique features without exaggeration.

### 6.2 Chapter 2: System Requirements

Target length: about 7 body pages.

Required subsections:

- `2.1 Introduction`
- `2.2 Feasibility Study`
- `2.2.1 Technical Feasibility`
- `2.2.2 Economic Feasibility`
- `2.2.3 Operational Feasibility`
- `2.3 System Requirements`
- `2.3.1 Functional Requirements`
- `2.3.2 Non-Functional Requirements`
- `2.4 Software Requirements Specification (SRS)`
- `2.5 Hardware Requirements`
- `2.6 Database Design Overview`
- `2.7 SDLC Model Used`
- `2.8 Summary`

Content directives:

- Functional requirements should map directly to system modules.
- Non-functional requirements should include scalability, security, performance, usability, maintainability, and portability where relevant.
- Hardware requirements can be modest and realistic for development and deployment.
- Database overview should name the main collections/tables/entities and their purpose.
- Mention the selected SDLC model briefly here; explain it fully in Chapter 4.

### 6.3 Chapter 3: System Design

Target length: about 11 body pages.

Required subsections:

- `3.1 Introduction`
- `3.2 Design Approach`
- `3.3 System Architecture`
- `3.3.1 Data Flow Diagram (DFD)`
- `3.3.2 UML Class Diagram`
- `3.4 Database Design`
- `3.5 Module Description`
- `3.6 User Interface Design`
- `3.7 Summary`

Content directives:

- Explain frontend, backend, database, external APIs, and AI/service modules as applicable.
- Include or describe an architecture diagram.
- Include or describe a DFD showing user input, processing, storage, and output.
- Include or describe a UML/class/entity diagram.
- Database design should list important entities/collections/tables with key fields.
- Module description should cover each main feature independently.
- UI design should describe the main screens and user workflow.

### 6.4 Chapter 4: Software Model

Target length: about 5 body pages.

Required subsections:

- `4.1 Introduction`
- `4.2 Agile Software Development Model`
- `4.3 Phases of Agile Model`
- `4.4 Advantages of Agile Model`
- `4.5 Limitations of Agile Model`
- `4.6 Expected Outcome`
- `4.7 Summary`

Content directives:

- Use Agile by default unless the project clearly used another model.
- Explain phases such as requirement analysis, planning, design, implementation, testing, deployment, and maintenance.
- Connect the model to the actual project workflow.

### 6.5 Chapter 5: Tools and Technologies

Target length: about 5 body pages.

Required subsections:

- `5.1 Introduction`
- `5.2 Frontend Technologies`
- `5.3 Backend Technologies`
- `5.4 Database Technologies`
- `5.5 Authentication Technologies`
- `5.6 Artificial Intelligence Technologies` if applicable
- `5.7 API Integration`
- `5.8 Development Tools`
- `5.9 Testing Tools`
- `5.10 Summary`

Content directives:

- Adapt subsections to the actual stack.
- For a MERN project, include React.js, Node.js, Express.js, MongoDB, Mongoose, JWT, bcrypt, npm, Git/GitHub, VS Code, and Postman where applicable.
- For AI projects, include the model/API provider and what it is used for.
- For non-AI projects, replace the AI section with a domain-specific technology section.
- Do not list unused technologies.

### 6.6 Chapter 6: Implementation

Target length: about 4 body pages.

Required subsections:

- `6.1 Introduction`
- `6.2 System Environment`
- `6.2.1 Frontend Environment`
- `6.2.2 Backend Environment`
- `6.2.3 Database Environment`
- `6.2.4 External/API/AI Integration Environment` if applicable
- `6.2.5 Development Tools`
- `6.3 Implementation Process`
- `6.3.1 Environment Setup`
- `6.3.2 Database Implementation`
- `6.3.3 Authentication Module Implementation` if applicable
- Additional module implementation subsections as needed.
- `6.4 Testing and Debugging`
- `6.5 Deployment`
- `6.6 Challenges Faced`
- `6.7 Solutions Implemented`
- `6.8 Summary`

Content directives:

- Describe implementation in prose; do not paste large code blocks.
- Mention folder/module organization only when it helps explain the system.
- Connect each implementation step to an actual feature.
- Deployment should be accurate. If not deployed, describe the intended deployment setup or local execution.

### 6.7 Chapter 7: Results

Target length: about 9 body pages.

Required subsections:

- `7.1 Introduction`
- `7.2 Overview of System Outcomes`
- `7.3 Functional Testing Results`
- Module-specific testing subsections, such as authentication, upload/processing, analysis, matching, dashboard, or reporting.
- `7.4 AI Performance Evaluation` if applicable
- `7.5 User Interface Evaluation`
- `7.5.1 Usability Testing`
- `7.5.2 Responsiveness Testing`
- `7.5.3 Performance Testing`
- `7.6 System Performance Evaluation`
- `7.7 Comparative Analysis`
- `7.8 Discussion`
- `7.9 Screenshots and Output Overview`
- `7.10 Summary`

Content directives:

- Present results as completed system behavior, not future promises.
- Include tables for functional testing where helpful.
- For AI features, describe output quality, limitations, and validation approach.
- Comparative analysis should compare the proposed system with the existing/manual system.
- Mention screenshots that will appear in Chapter 8.

### 6.8 Chapter 8: Snapshots

Target length: about 4 body pages.

Required subsections:

- `8.1 Introduction`
- One subsection per major screen/workflow.
- `8.6 Summary` or the next available number after screenshots.

Content directives:

- Include clear screenshots with short captions.
- Cover login/signup, dashboard/home, main feature pages, result/output pages, and generated/downloaded output where relevant.
- Screenshots should be readable and not overly cropped.
- Do not include duplicate screenshots unless they show distinct states.

### 6.9 Chapter 9: Conclusion

Target length: about 1 body page.

Required subsection:

- `9.1 Conclusion`

Content directives:

- Summarize the project achievement.
- Explain how the system solves the stated problem.
- Mention practical usefulness and learning outcome.
- Do not introduce new features here.

### 6.10 Chapter 10: Limitations

Target length: about 1 body page.

Content directives:

- List realistic limitations.
- Include technical, operational, data, deployment, security, accuracy, scalability, or usability constraints as applicable.
- Be honest but not self-defeating.

### 6.11 Chapter 11: Future Enhancement

Target length: about 1 body page.

Content directives:

- List meaningful future improvements.
- Tie enhancements to real limitations or natural next steps.
- Examples: mobile app, advanced analytics, improved AI model, multi-language support, cloud deployment, richer admin panel, more integrations, better security, browser extension, notifications, or reporting.

### 6.12 Chapter 12: Bibliography

Target length: about 1 body page.

Content directives:

- Include official documentation for frameworks, libraries, databases, APIs, and tools used.
- Include academic/project references if relevant.
- Prefer official sources over random tutorials.
- Keep formatting consistent.

## 7. Writing Style Directives

- Use formal academic language.
- Write in third person or first-person plural consistently.
- Keep paragraphs medium length and readable.
- Avoid marketing tone.
- Avoid unverifiable claims such as "best", "perfect", or "fully secure".
- Explain technical terms briefly when first used.
- Use bullet points for objectives, requirements, limitations, and future enhancements.
- Use tables for requirements, testing results, technology lists, and module summaries where useful.
- Do not copy sample-specific names, enrollment numbers, screenshots, or project details into another report.

## 8. Diagram and Screenshot Requirements

Include these visual elements when possible:

- System architecture diagram.
- Data Flow Diagram.
- UML class diagram or entity relationship diagram.
- Database schema/table/collection overview.
- Screenshots of major user workflows.

Each figure should have:

- Figure number.
- Caption.
- Short explanation in the surrounding text.

## 9. Page Planning Guide

Use this approximate body-page budget:

| Chapter | Pages |
| --- | ---: |
| Introduction | 6 |
| System Requirements | 7 |
| System Design | 11 |
| Software Model | 5 |
| Tools and Technologies | 5 |
| Implementation | 4 |
| Results | 9 |
| Snapshots | 4 |
| Conclusion | 1 |
| Limitations | 1 |
| Future Enhancement | 1 |
| Bibliography | 1 |

The target body length is about 55 pages, plus front matter and index. It is acceptable to vary the final length if the codebase complexity requires it, but the table of contents must be updated accordingly.

## 10. Final QA Checklist

Before delivering the report:

- Front matter is complete and names/designations are correct.
- Index uses the required 12-chapter structure.
- Body page numbering starts from the Introduction.
- Page ranges in the index match the final document.
- All headings are numbered consistently.
- Chapter names are spelled consistently.
- Technologies listed are actually used by the codebase.
- Requirements match real system features.
- Diagrams and screenshots are readable.
- Results and testing sections describe actual behavior.
- Limitations and future enhancements are realistic.
- Bibliography includes official documentation for important tools and APIs.
- No sample-specific data remains unless the report is for that same sample project.

## 11. DOCX Production Contract

The final report should be delivered as a `.docx` file unless the user asks for another format. Markdown may be used as an intermediate draft, but the deliverable must be a Word document.

### 11.1 DOCX Layout Requirements

Use these Word document rules:

- Page size: A4 or Letter, based on institution requirement. If unknown, use A4 for Indian college reports.
- Margins: about 1 inch on all sides.
- Body font: Times New Roman or Calibri, 11-12 pt. Use one consistently.
- Line spacing: 1.15 or 1.5 for academic readability.
- Major chapter headings: uppercase, bold, centered or left aligned consistently.
- Subsection headings: numbered, bold, title case.
- Body page numbering starts at Chapter 1.
- Front matter pages may use no visible page number or separate roman numbering if required.
- Insert page breaks between front matter pages and major chapters.
- Use a real table for the index.
- Use real Word headings so a Word table of contents can be generated later if needed.
- Use captions for figures and screenshots.
- Keep screenshots near the text that introduces them.

### 11.2 DOCX Section Breaks and Page Numbering

For a full report, use at least two document sections:

1. Front matter section: cover, certificate, acknowledgement, contribution, index.
2. Body section: chapters 1-12, with page numbering restarted at 1.

If tooling cannot create automatic restarted page numbers safely, use a visible page number convention only after layout review, or omit footer page numbers and ensure the index still uses final body page estimates.

### 11.3 Tables and Figures

Use tables for:

- Index.
- Technology stack.
- Functional requirements.
- Non-functional requirements.
- API endpoint summary.
- Testing results.
- Hardware/software requirements.
- Database/entity overview.

Use prose or bullets instead of tables when:

- The content is long explanation.
- Cells would contain full paragraphs.
- A list of features reads better as bullets.

Figures should include:

- System architecture diagram.
- Data flow diagram.
- UML/class/entity diagram when relevant.
- Screenshots of main workflows.

If screenshots are missing, create clearly marked placeholders such as:

```text
[Insert Screenshot: Dashboard showing ATS score and analysis results]
```

Do not fabricate screenshots.

### 11.4 Report Generation Algorithm

Follow this algorithm when generating a report from a codebase:

1. Create `artifacts/report_work/` or another working directory.
2. Save an internal codebase fact sheet.
3. Draft front matter with placeholders for unknown names/designations.
4. Draft the index using the required 12 chapters.
5. Draft Chapter 1 from project purpose, problem, objectives, existing/proposed system, and unique features.
6. Draft Chapter 2 from dependencies, runtime requirements, functional/non-functional requirements, and storage design.
7. Draft Chapter 3 from architecture, routes, modules, data flow, UI screens, and data structures.
8. Draft Chapter 4 using Agile unless another model is clearly documented.
9. Draft Chapter 5 from actual technologies used.
10. Draft Chapter 6 from setup files, implementation modules, build/deploy scripts, and challenges.
11. Draft Chapter 7 from observable outputs, API behavior, UI results, and testing evidence.
12. Draft Chapter 8 with screenshot placeholders or actual screenshots.
13. Draft Chapters 9-12 with concise conclusion, limitations, future enhancement, and bibliography.
14. Generate the DOCX.
15. Render and inspect pages if rendering tools are available.
16. Revise the DOCX until layout is readable.

### 11.5 Factual Guardrails

The agent must not:

- Claim a database exists when the app uses file-based JSON or browser localStorage only.
- Claim real LLM integration when the code uses rule-based logic.
- Claim authentication exists unless login/session/password code is present.
- Claim cloud deployment is complete unless deployment files or user confirmation support it.
- Claim automated tests passed unless tests were actually run.
- Claim a feature is production-ready when the code or docs describe it as a prototype, fallback, or development setup.

When a useful feature is absent, place it in Limitations or Future Enhancement.

### 11.6 Unknown Information Policy

If institution, student, guide, HOD, director, enrollment numbers, or session details are unknown, use bracketed placeholders:

```text
[College Name]
[Student Name 1] ([Enrollment Number])
[Guide Name], [Designation]
```

Do not invent personal or institutional data. The user can replace placeholders later.

### 11.7 Minimum Deliverable Quality

A first DOCX draft is acceptable only if it includes:

- Complete front matter placeholders.
- Required index/table of contents.
- All 12 chapters in the required order.
- Codebase-specific technologies and modules.
- At least one architecture/data-flow explanation.
- Real limitations based on the codebase.
- Bibliography entries for major tools.

A final DOCX should also include:

- Accurate page ranges.
- Real screenshots.
- Rendered visual QA.
- Correct institutional details.
- Clean page breaks and captions.

## 12. Agent-Ready Report Skeleton

Use this skeleton when drafting:

```text
Cover Page
Certificate
Acknowledgement
Group Members and Personal Contribution
Index

1. INTRODUCTION
1.1 Introduction to Project
1.2 Project Category
1.3 Objectives
1.4 Problem Formulation
1.5 Identification of Need
1.6 Existing System
1.7 Proposed System
1.7.1 Unique Features of the System

2. SYSTEM REQUIREMENTS
2.1 Introduction
2.2 Feasibility Study
2.2.1 Technical Feasibility
2.2.2 Economic Feasibility
2.2.3 Operational Feasibility
2.3 System Requirements
2.3.1 Functional Requirements
2.3.2 Non-Functional Requirements
2.4 Software Requirements Specification (SRS)
2.5 Hardware Requirements
2.6 Database Design Overview
2.7 SDLC Model Used
2.8 Summary

3. SYSTEM DESIGN
3.1 Introduction
3.2 Design Approach
3.3 System Architecture
3.3.1 Data Flow Diagram (DFD)
3.3.2 UML Class Diagram
3.4 Database Design
3.5 Module Description
3.6 User Interface Design
3.7 Summary

4. SOFTWARE MODEL
4.1 Introduction
4.2 Agile Software Development Model
4.3 Phases of Agile Model
4.4 Advantages of Agile Model
4.5 Limitations of Agile Model
4.6 Expected Outcome
4.7 Summary

5. TOOLS AND TECHNOLOGIES
5.1 Introduction
5.2 Frontend Technologies
5.3 Backend Technologies
5.4 Database/Storage Technologies
5.5 Authentication/Security Technologies
5.6 AI/ML/NLP Technologies
5.7 API Integration
5.8 Development Tools
5.9 Testing Tools
5.10 Summary

6. IMPLEMENTATION
6.1 Introduction
6.2 System Environment
6.3 Implementation Process
6.4 Testing and Debugging
6.5 Deployment
6.6 Challenges Faced
6.7 Solutions Implemented
6.8 Summary

7. RESULTS
7.1 Introduction
7.2 Overview of System Outcomes
7.3 Functional Testing Results
7.4 AI/ML/NLP Performance Evaluation
7.5 User Interface Evaluation
7.6 System Performance Evaluation
7.7 Comparative Analysis
7.8 Discussion
7.9 Screenshots and Output Overview
7.10 Summary

8. SNAPSHOTS
8.1 Introduction
8.2 Main Interface
8.3 Resume Upload and Role Selection
8.4 Analysis Result Dashboard
8.5 Keyword Gap and Formatting Output
8.6 Career Coach / Additional Workflow
8.7 Summary

9. CONCLUSION
9.1 Conclusion

10. LIMITATIONS

11. FUTURE ENHANCEMENT

12. BIBLIOGRAPHY
```

## 13. Reusable Generation Prompt

Use this prompt when asking an AI assistant to generate a similar report:

```text
Analyze the codebase at [CODEBASE_PATH] and create a formal major project report using docs/PROJECT_REPORT_DIRECTIVES.md as the structure and formatting guide.

Before writing, inspect the whole codebase and create a source-backed fact sheet covering project purpose, modules, frontend, backend, data/storage, APIs, AI/ML logic, deployment, tests, limitations, and screenshots required.

Use the required 12-chapter index:
1. INTRODUCTION
2. SYSTEM REQUIREMENTS
3. SYSTEM DESIGN
4. SOFTWARE MODEL
5. TOOLS AND TECHNOLOGIES
6. IMPLEMENTATION
7. RESULTS
8. SNAPSHOTS
9. CONCLUSION
10. LIMITATIONS
11. FUTURE ENHANCEMENT
12. BIBLIOGRAPHY

Generate a `.docx` report. Do not invent unused technologies, database features, authentication, deployment status, tests, or AI integrations. Use placeholders for unknown institution/student details. Keep the report formal and academic. Start body page numbering at Chapter 1, and update the index page ranges after layout.
```
