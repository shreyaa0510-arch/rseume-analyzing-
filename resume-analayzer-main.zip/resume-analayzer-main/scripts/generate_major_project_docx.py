from docx import Document
from docx.enum.section import WD_SECTION_START
from docx.enum.table import WD_ALIGN_VERTICAL, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
OUT_DIR = ROOT / "artifacts"
OUT_FILE = OUT_DIR / "AI_Resume_Analyzer_Major_Project_Report.docx"
SCREENSHOT_DIR = OUT_DIR / "report_screenshots"


PROJECT = {
    "title": "AI Resume Analyzer",
    "subtitle": "A Natural Language Processing Based Resume Evaluation and Career Intelligence System",
    "college": "[College Name]",
    "location": "[College Location]",
    "department": "Computer Science & Engineering",
    "university": "[University Name]",
    "degree": "Bachelor of Technology",
    "session": "[Academic Session]",
    "guide": "[Guide Name], [Designation]",
    "hod": "[HOD Name], Head of Department",
    "director": "[Director/Principal Name], Director/Principal",
    "students": [
        ("[Student Name 1]", "[Enrollment Number]"),
        ("[Student Name 2]", "[Enrollment Number]"),
        ("[Student Name 3]", "[Enrollment Number]"),
        ("[Student Name 4]", "[Enrollment Number]"),
    ],
}


TOC = [
    ("1.", "INTRODUCTION", "1-4"),
    ("2.", "SYSTEM REQUIREMENTS", "5-8"),
    ("3.", "SYSTEM DESIGN", "9-13"),
    ("4.", "SOFTWARE MODEL", "14-16"),
    ("5.", "TOOLS AND TECHNOLOGIES", "17-19"),
    ("6.", "IMPLEMENTATION", "20-23"),
    ("7.", "RESULTS", "24-28"),
    ("8.", "SNAPSHOTS", "29-37"),
    ("9.", "CONCLUSION", "38-39"),
    ("10.", "LIMITATIONS", "40-41"),
    ("11.", "FUTURE ENHANCEMENT", "42-43"),
    ("12.", "BIBLIOGRAPHY", "44"),
]


def set_cell_shading(cell, fill):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:fill"), fill)
    tc_pr.append(shd)


def set_cell_width(cell, width):
    tc = cell._tc
    tc_pr = tc.get_or_add_tcPr()
    tc_w = tc_pr.first_child_found_in("w:tcW")
    if tc_w is None:
        tc_w = OxmlElement("w:tcW")
        tc_pr.append(tc_w)
    tc_w.set(qn("w:w"), str(width))
    tc_w.set(qn("w:type"), "dxa")


def set_table_borders(table, color="BFBFBF", size="6"):
    tbl = table._tbl
    tbl_pr = tbl.tblPr
    borders = tbl_pr.first_child_found_in("w:tblBorders")
    if borders is None:
        borders = OxmlElement("w:tblBorders")
        tbl_pr.append(borders)
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        tag = "w:{}".format(edge)
        element = borders.find(qn(tag))
        if element is None:
            element = OxmlElement(tag)
            borders.append(element)
        element.set(qn("w:val"), "single")
        element.set(qn("w:sz"), size)
        element.set(qn("w:space"), "0")
        element.set(qn("w:color"), color)


def add_page_number(paragraph):
    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = paragraph.add_run()
    fld_char_1 = OxmlElement("w:fldChar")
    fld_char_1.set(qn("w:fldCharType"), "begin")
    instr_text = OxmlElement("w:instrText")
    instr_text.set(qn("xml:space"), "preserve")
    instr_text.text = "PAGE"
    fld_char_2 = OxmlElement("w:fldChar")
    fld_char_2.set(qn("w:fldCharType"), "end")
    run._r.append(fld_char_1)
    run._r.append(instr_text)
    run._r.append(fld_char_2)


def restart_page_numbering(section, start=1):
    sect_pr = section._sectPr
    pg_num_type = sect_pr.find(qn("w:pgNumType"))
    if pg_num_type is None:
        pg_num_type = OxmlElement("w:pgNumType")
        sect_pr.append(pg_num_type)
    pg_num_type.set(qn("w:start"), str(start))


def configure_document(doc):
    section = doc.sections[0]
    section.page_width = Inches(8.27)
    section.page_height = Inches(11.69)
    for sec in doc.sections:
        sec.top_margin = Inches(1)
        sec.bottom_margin = Inches(1)
        sec.left_margin = Inches(1)
        sec.right_margin = Inches(1)

    styles = doc.styles
    normal = styles["Normal"]
    normal.font.name = "Times New Roman"
    normal._element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
    normal.font.size = Pt(12)
    normal.paragraph_format.line_spacing = 1.15
    normal.paragraph_format.space_after = Pt(6)

    for name, size, color in [
        ("Heading 1", 16, "1F4E79"),
        ("Heading 2", 13, "1F4E79"),
        ("Heading 3", 12, "1F4E79"),
    ]:
        style = styles[name]
        style.font.name = "Times New Roman"
        style._element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
        style.font.bold = True
        style.font.size = Pt(size)
        style.font.color.rgb = RGBColor.from_string(color)
        style.paragraph_format.space_before = Pt(10)
        style.paragraph_format.space_after = Pt(6)
        style.paragraph_format.keep_with_next = True


def add_centered(doc, text, size=12, bold=False, space_after=6):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(space_after)
    run = p.add_run(text)
    run.bold = bold
    run.font.name = "Times New Roman"
    run._element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
    run.font.size = Pt(size)
    return p


def add_body(doc, text, align=WD_ALIGN_PARAGRAPH.JUSTIFY):
    p = doc.add_paragraph()
    p.alignment = align
    p.paragraph_format.line_spacing = 1.15
    p.paragraph_format.space_after = Pt(6)
    p.add_run(text)
    return p


def add_bullet(doc, text):
    p = doc.add_paragraph(style="List Bullet")
    p.paragraph_format.space_after = Pt(3)
    p.add_run(text)
    return p


def add_numbered(doc, text):
    p = doc.add_paragraph(style="List Number")
    p.paragraph_format.space_after = Pt(3)
    p.add_run(text)
    return p


def add_heading(doc, text, level=1):
    p = doc.add_heading(text, level=level)
    if level == 1:
        p.alignment = WD_ALIGN_PARAGRAPH.LEFT
    return p


def add_caption(doc, text):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(2)
    p.paragraph_format.space_after = Pt(8)
    run = p.add_run(text)
    run.italic = True
    run.font.size = Pt(10)
    return p


def add_table(doc, headers, rows, widths=None):
    table = doc.add_table(rows=1, cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.style = "Table Grid"
    set_table_borders(table)
    hdr_cells = table.rows[0].cells
    for idx, header in enumerate(headers):
        hdr_cells[idx].text = header
        set_cell_shading(hdr_cells[idx], "D9EAF7")
        hdr_cells[idx].vertical_alignment = WD_ALIGN_VERTICAL.CENTER
        for paragraph in hdr_cells[idx].paragraphs:
            paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
            if paragraph.runs:
                paragraph.runs[0].bold = True
    for row in rows:
        cells = table.add_row().cells
        for idx, value in enumerate(row):
            cells[idx].text = str(value)
            cells[idx].vertical_alignment = WD_ALIGN_VERTICAL.CENTER
    if widths:
        for row in table.rows:
            for idx, width in enumerate(widths):
                set_cell_width(row.cells[idx], width)
    doc.add_paragraph()
    return table


def add_placeholder_box(doc, text):
    table = doc.add_table(rows=1, cols=1)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    set_table_borders(table, color="7F7F7F", size="8")
    cell = table.cell(0, 0)
    set_cell_shading(cell, "F2F2F2")
    cell.text = text
    cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
    for paragraph in cell.paragraphs:
        paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
        for run in paragraph.runs:
            run.bold = True
    doc.add_paragraph()
    return table


def add_screenshot(doc, filename, caption):
    image_path = SCREENSHOT_DIR / filename
    if image_path.exists():
        width = Inches(3.0) if filename.startswith(("07_", "08_")) else Inches(6.2)
        doc.add_picture(str(image_path), width=width)
        doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
        add_caption(doc, caption)
        doc.add_page_break()
    else:
        add_placeholder_box(doc, "[Insert Screenshot: {}]".format(caption))


def cover_page(doc):
    add_centered(doc, PROJECT["college"].upper(), 16, True, 2)
    add_centered(doc, PROJECT["location"].upper(), 13, True, 24)
    add_centered(doc, "MAJOR PROJECT REPORT", 18, True, 10)
    add_centered(doc, "ON", 13, True, 10)
    add_centered(doc, '"{}"'.format(PROJECT["title"].upper()), 20, True, 8)
    add_centered(doc, PROJECT["subtitle"], 13, False, 30)
    add_centered(
        doc,
        "Submitted in partial fulfillment of {} Degree in {}".format(PROJECT["degree"], PROJECT["department"]),
        12,
        False,
        8,
    )
    add_centered(doc, "Of", 12, False, 8)
    add_centered(doc, PROJECT["university"].upper(), 13, True, 28)
    add_centered(doc, "Submitted By:", 12, True, 8)
    for name, enrollment in PROJECT["students"]:
        add_centered(doc, "{} ({})".format(name, enrollment), 12, False, 2)
    add_centered(doc, "Session {}".format(PROJECT["session"]), 12, True, 0)
    doc.add_page_break()


def certificate_page(doc):
    add_centered(doc, PROJECT["college"].upper(), 16, True, 2)
    add_centered(doc, PROJECT["location"].upper(), 13, True, 2)
    add_centered(doc, "({})".format(PROJECT["department"].upper()), 12, True, 18)
    add_centered(doc, "CERTIFICATE", 16, True, 18)
    names = ", ".join("{} ({})".format(name, enrollment) for name, enrollment in PROJECT["students"])
    add_body(
        doc,
        'It is certified that the project report entitled "{}" presented by {} is the bona fide presentation of the work done by them under supervision and guidance. The project report has been submitted towards partial fulfillment of the requirements for the award of the degree of {} of {}, during the academic session {}. It is further certified that this work has not been submitted elsewhere for the award of any degree or diploma.'.format(
            PROJECT["title"],
            names,
            PROJECT["degree"],
            PROJECT["university"],
            PROJECT["session"],
        ),
    )
    doc.add_paragraph()
    table = add_table(
        doc,
        ["Approved By", "Guided By"],
        [
            [PROJECT["hod"], PROJECT["guide"]],
            [PROJECT["director"], ""],
        ],
        widths=[4500, 4500],
    )
    for row in table.rows:
        for cell in row.cells:
            for paragraph in cell.paragraphs:
                paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    doc.add_page_break()


def acknowledgement_page(doc):
    add_centered(doc, "ACKNOWLEDGEMENT", 16, True, 18)
    paragraphs = [
        "We are deeply indebted to the faculty members, colleagues, friends, and professionals who offered guidance, insight, and support throughout the development of this project.",
        "Foremost among the faculty, our gratitude is due to {} for providing motivation and the required institutional facilities. We are equally thankful to {} for academic support and encouragement during the selection, design, and testing of the project.".format(PROJECT["director"], PROJECT["hod"]),
        "We express sincere thanks to {} for guiding the work, reviewing the implementation approach, and helping us organize the project report in a systematic manner.".format(PROJECT["guide"]),
        "This project would not have been completed successfully without the support, patience, and cooperation of our classmates, lab staff, faculty members, and family. We also thank our parents and the Almighty for their blessings.",
    ]
    for text in paragraphs:
        add_body(doc, text)
    add_body(doc, "Group Members:", WD_ALIGN_PARAGRAPH.LEFT)
    for name, enrollment in PROJECT["students"]:
        add_bullet(doc, "{} ({})".format(name, enrollment))
    doc.add_page_break()


def contribution_page(doc):
    add_centered(doc, PROJECT["title"].upper(), 16, True, 12)
    add_body(doc, "OUR GROUP MEMBERS:", WD_ALIGN_PARAGRAPH.LEFT)
    for idx, (name, enrollment) in enumerate(PROJECT["students"], 1):
        add_numbered(doc, "{} ({})".format(name, enrollment))
    doc.add_paragraph()
    add_body(doc, "PERSONAL CONTRIBUTION IN THE PROJECT:", WD_ALIGN_PARAGRAPH.LEFT)
    contributions = [
        "contributed to requirement collection, project coordination, documentation planning, and validation of report content against the implemented features.",
        "contributed to backend implementation, API understanding, NLP analysis workflow, role data interpretation, and deployment configuration review.",
        "contributed to frontend workflow analysis, user interface documentation, result dashboard review, and snapshot planning.",
        "contributed to testing support, limitation analysis, bibliography preparation, and final report formatting review.",
    ]
    for (name, enrollment), contribution in zip(PROJECT["students"], contributions):
        add_body(doc, "{} ({}) - {}".format(name, enrollment, contribution))
    doc.add_page_break()


def index_page(doc):
    add_centered(doc, "INDEX", 16, True, 18)
    add_table(doc, ["S. NO.", "CONTENTS", "PAGE NO."], TOC, widths=[1200, 6000, 1800])
    note = "Note: Page numbers follow the reference report format and should be updated after inserting final screenshots and institutional details."
    add_body(doc, note, WD_ALIGN_PARAGRAPH.LEFT)


def add_system_architecture_figure(doc):
    rows = [
        ["User Browser", "Static frontend built with HTML, CSS, JavaScript, Chart.js, file upload form, result dashboard, and chat widget."],
        ["FastAPI Server", "Receives PDF/DOCX uploads, validates file type, stores uploaded file temporarily, exposes /analyze, /upload-resume, and /chat endpoints."],
        ["Text Extraction Layer", "Uses pdfplumber for PDF files and python-docx for DOCX files, then cleans and prepares resume text."],
        ["NLP/ML Analyzer", "Uses heuristic section extraction, spaCy where available, TF-IDF vectorization, cosine similarity, keyword density, and formatting checks."],
        ["Role Data Store", "Uses backend/roles.json as a file-based role benchmark database containing core skills, tools, and description keywords for 16+ roles."],
        ["Output Dashboard", "Displays ATS score, match percentage, strengths, weaknesses, suggestions, missing keywords, formatting report, radar chart, history, and chat response."],
    ]
    add_table(doc, ["Layer", "Responsibility"], rows, widths=[2200, 7000])
    add_caption(doc, "Figure 3.1: System architecture of the AI Resume Analyzer")


def chapter_1(doc):
    add_heading(doc, "1. INTRODUCTION", 1)
    add_heading(doc, "1.1 Introduction to Project", 2)
    for text in [
        "The process of preparing a resume has become increasingly important in the modern recruitment environment. Job seekers are expected to create resumes that are concise, structured, keyword-aware, and compatible with Applicant Tracking Systems. However, many candidates prepare resumes without knowing whether their skills, experience, project descriptions, and education details match the expectations of a selected job role.",
        "The project titled AI Resume Analyzer is designed to address this problem through a web-based resume evaluation system. It allows a user to upload a resume in PDF or DOCX format, select a target job role, optionally paste a job description, and receive an analysis report containing an ATS compatibility score, semantic match percentage, missing keywords, formatting feedback, and improvement suggestions.",
        "The system uses Natural Language Processing and Machine Learning techniques such as text extraction, section identification, TF-IDF vectorization, cosine similarity, keyword density analysis, and rule-based feedback generation. The frontend provides a user-friendly dashboard with a score ring, radar chart, keyword tags, analysis history, and a career coach chat interface.",
    ]:
        add_body(doc, text)
    add_heading(doc, "1.2 Project Category", 2)
    add_body(doc, "This project belongs to the category of web application development with Natural Language Processing and Machine Learning integration. It is a full-stack application in the practical sense because it combines a browser-based frontend, a FastAPI backend, file parsing utilities, a role benchmark data source, and an analysis engine.")
    add_body(doc, "Unlike a simple static resume checker, the project applies role-specific comparison and semantic matching. The application is therefore suitable for the academic category of AI/NLP-assisted application development.")
    add_heading(doc, "1.3 Objectives", 2)
    objectives = [
        "To provide an easy-to-use web interface for uploading resumes in PDF and DOCX formats.",
        "To extract resume text and identify important sections such as skills, experience, projects, and education.",
        "To calculate an overall ATS compatibility score out of 100.",
        "To compare resume content with a selected job role or optional job description using TF-IDF and cosine similarity.",
        "To identify missing role-specific keywords and overused words.",
        "To provide formatting suggestions related to resume length, bullet usage, and structure.",
        "To present results through a modern dashboard with charts, tags, and feedback panels.",
        "To provide a rule-based career coach chat interface that explains analysis results to the user.",
    ]
    for item in objectives:
        add_bullet(doc, item)
    add_heading(doc, "1.4 Problem Formulation", 2)
    add_body(doc, "Many job seekers submit resumes without knowing whether their documents are aligned with the target job role. Traditional manual review requires expert knowledge and may not be available to every candidate. Existing online systems often provide generic feedback, while candidates need practical and role-specific recommendations.")
    add_body(doc, "The problem can be formulated as follows: given a resume document and a target job role or job description, the system must extract text, analyze resume structure, compare the resume against relevant role keywords, calculate compatibility scores, identify gaps, and generate useful feedback in a readable format.")
    add_heading(doc, "1.5 Identification of Need", 2)
    for item in [
        "Students and freshers need guidance to improve resumes before applying for internships or jobs.",
        "Candidates need to understand missing skills and keywords for specific roles.",
        "Manual resume checking is time-consuming and inconsistent.",
        "Recruitment systems increasingly rely on keyword and structure matching.",
        "A local web application can provide quick feedback without requiring complex installation for end users.",
    ]:
        add_bullet(doc, item)
    add_heading(doc, "1.6 Existing System", 2)
    add_body(doc, "In the existing manual approach, a candidate usually asks a teacher, mentor, friend, or career counselor to review the resume. This process depends on the reviewer availability and expertise. Generic resume templates and online tips are helpful, but they do not analyze the actual resume content against a target role.")
    add_body(doc, "Some resume tools provide formatting checks or keyword suggestions, but many are limited, paid, or not transparent about their scoring logic. They may also fail to show how skills, experience, education, and projects contribute to the final evaluation.")
    add_heading(doc, "1.7 Proposed System", 2)
    add_body(doc, "The proposed system automates resume evaluation through a FastAPI backend and a static web frontend. The user uploads a resume, selects a role, and optionally provides a job description. The backend extracts text, runs the analysis pipeline, and returns a structured JSON response. The frontend visualizes the response through score cards, keyword tags, recommendations, and charts.")
    add_body(doc, "The application currently uses file-based role data instead of a database. It stores uploaded resumes in an uploads directory during processing and keeps analysis history in browser localStorage. This makes the system simpler to run for academic demonstration while still showing a complete resume analysis workflow.")
    add_screenshot(doc, "01_main_interface.png", "Figure 1.1: Main interface of the proposed AI Resume Analyzer system")
    add_heading(doc, "1.7.1 Unique Features of the System", 2)
    for item in [
        "Supports both PDF and DOCX resume input.",
        "Provides 16+ predefined job role benchmarks through a JSON role database.",
        "Allows custom role input and optional job description matching.",
        "Combines section scoring with semantic TF-IDF similarity.",
        "Detects missing keywords, overused words, language, and formatting issues.",
        "Shows results through an animated dashboard and Chart.js radar chart.",
        "Includes a rule-based AI Career Coach for result explanation.",
        "Maintains the last five analysis results in browser localStorage.",
    ]:
        add_bullet(doc, item)
    doc.add_page_break()


def chapter_2(doc):
    add_heading(doc, "2. SYSTEM REQUIREMENTS", 1)
    add_heading(doc, "2.1 Introduction", 2)
    add_body(doc, "System requirements define the services, behavior, resources, and constraints necessary to develop and operate the AI Resume Analyzer. The requirements are derived from the implemented codebase, dependency files, setup documentation, and deployment configuration.")
    add_heading(doc, "2.2 Feasibility Study", 2)
    add_heading(doc, "2.2.1 Technical Feasibility", 3)
    add_body(doc, "The project is technically feasible because it uses widely available open-source technologies. FastAPI provides the server layer, pdfplumber and python-docx support document extraction, spaCy and scikit-learn support NLP and vector matching, and the frontend is built with standard HTML, CSS, and JavaScript.")
    add_heading(doc, "2.2.2 Economic Feasibility", 3)
    add_body(doc, "The system is economically feasible because it can be developed and demonstrated using free tools and libraries. The deployment configuration targets Render's free web service plan, and the frontend does not require paid build tools or proprietary frameworks.")
    add_heading(doc, "2.2.3 Operational Feasibility", 3)
    add_body(doc, "The system is operationally feasible because users interact with a simple browser interface. The workflow is direct: choose a role, upload a resume, optionally paste a job description, click Analyze Resume, and review the generated feedback.")
    add_heading(doc, "2.3 System Requirements", 2)
    add_heading(doc, "2.3.1 Functional Requirements", 3)
    add_table(
        doc,
        ["Requirement", "Description"],
        [
            ["Resume Upload", "The system shall accept resume files in PDF and DOCX formats."],
            ["Role Selection", "The system shall allow the user to choose from predefined job roles or enter a custom role."],
            ["Job Description Input", "The system shall accept an optional job description for improved role matching."],
            ["Text Extraction", "The system shall extract text from uploaded PDF and DOCX resumes."],
            ["ATS Scoring", "The system shall calculate an overall score using section scores and semantic match bonus."],
            ["Keyword Gap Analysis", "The system shall identify role-specific missing keywords."],
            ["Formatting Audit", "The system shall detect length and bullet point related issues."],
            ["Result Dashboard", "The system shall display score, language, section scores, feedback, missing keywords, and chart output."],
            ["Career Coach Chat", "The system shall answer common questions about score, missing skills, formatting, and suggestions using analysis context."],
            ["History Tracking", "The system shall save recent analysis scores in browser localStorage."],
        ],
        widths=[2500, 6700],
    )
    add_screenshot(doc, "03_upload_ready.png", "Figure 2.1: User input requirements represented through resume selection and job description input")
    add_heading(doc, "2.3.2 Non-Functional Requirements", 3)
    add_table(
        doc,
        ["Requirement", "Expected Quality"],
        [
            ["Usability", "The interface should be simple enough for students and job seekers to use without training."],
            ["Performance", "Resume analysis should complete within a short time for typical one or two page resumes."],
            ["Maintainability", "Backend logic should remain separated into route, analyzer, utility, and role data modules."],
            ["Portability", "The application should run on any system with Python 3.9+ and required dependencies."],
            ["Scalability", "The current implementation supports academic demonstration; future versions can add persistent storage and user accounts."],
            ["Security", "File validation is present for PDF/DOCX extension checks, but production use requires stronger file scanning and restricted CORS."],
        ],
        widths=[2500, 6700],
    )
    add_heading(doc, "2.4 Software Requirements Specification (SRS)", 2)
    add_table(
        doc,
        ["Component", "Requirement"],
        [
            ["Operating System", "Windows, Linux, or macOS with Python support."],
            ["Python", "Python 3.9+ for local development; Render config uses Python 3.11.9."],
            ["Server", "Uvicorn ASGI server running backend.main:app."],
            ["Backend Framework", "FastAPI with Pydantic validation and CORS middleware."],
            ["Frontend", "HTML5, CSS3, Vanilla JavaScript, Chart.js, Google Fonts."],
            ["NLP/ML", "spaCy, scikit-learn TF-IDF vectorizer, cosine similarity, langdetect."],
            ["File Processing", "pdfplumber for PDF and python-docx for DOCX parsing."],
        ],
        widths=[2500, 6700],
    )
    add_heading(doc, "2.5 Hardware Requirements", 2)
    add_table(
        doc,
        ["Hardware", "Recommended Requirement"],
        [
            ["Processor", "Dual core processor or higher."],
            ["RAM", "4 GB minimum; 8 GB recommended for smoother development."],
            ["Storage", "At least 1 GB free space for project files, dependencies, uploads, and artifacts."],
            ["Network", "Internet access for dependency installation, CDN assets, and optional deployment."],
        ],
        widths=[2500, 6700],
    )
    add_heading(doc, "2.6 Database Design Overview", 2)
    add_body(doc, "The current implementation does not use a traditional relational or NoSQL database. Instead, it uses file-based and browser-based storage mechanisms suitable for an academic prototype.")
    add_table(
        doc,
        ["Storage Element", "Purpose"],
        [
            ["backend/roles.json", "Stores role-specific core skills, tools, and description keywords for predefined job roles."],
            ["uploads directory", "Stores uploaded resume files temporarily during processing."],
            ["browser localStorage", "Stores the last five analysis history entries on the user's browser."],
            ["artifacts directory", "Stores generated project documentation or report artifacts."],
        ],
        widths=[2800, 6400],
    )
    add_heading(doc, "2.7 SDLC Model Used", 2)
    add_body(doc, "The Agile model is suitable for this project because features such as file upload, scoring, role matching, frontend visualization, chat response, and deployment can be developed and improved iteratively.")
    add_heading(doc, "2.8 Summary", 2)
    add_body(doc, "The system requirements show that the project can be built and run using accessible open-source tools. The major functional requirements revolve around resume upload, text extraction, analysis, visualization, and feedback generation.")
    doc.add_page_break()


def chapter_3(doc):
    add_heading(doc, "3. SYSTEM DESIGN", 1)
    add_heading(doc, "3.1 Introduction", 2)
    add_body(doc, "System design explains how the AI Resume Analyzer is organized internally and how the user-facing interface communicates with the backend analysis engine. The design follows a simple layered approach with a static frontend, FastAPI application server, text extraction utilities, analysis model, and file-based role data.")
    add_heading(doc, "3.2 Design Approach", 2)
    for item in [
        "Presentation Layer: HTML, CSS, and JavaScript files in the frontend directory render the upload form, role selection, result dashboard, radar chart, history, and chat widget.",
        "Application Layer: backend/main.py defines FastAPI routes, CORS configuration, upload handling, and static frontend mounting.",
        "Processing Layer: backend/utils.py extracts and cleans resume text, detects language, preprocesses tokens, and identifies resume sections.",
        "Analysis Layer: backend/model.py calculates scores, missing keywords, keyword density, formatting report, and chatbot responses.",
        "Data Layer: backend/roles.json stores role benchmark data used during matching.",
    ]:
        add_bullet(doc, item)
    add_heading(doc, "3.3 System Architecture", 2)
    add_system_architecture_figure(doc)
    add_body(doc, "The architecture is intentionally lightweight. The backend serves both the API and frontend static files, which simplifies local execution and deployment. API routes are defined before the static file mount so that API endpoints are not overridden by the frontend route.")
    add_heading(doc, "3.3.1 Data Flow Diagram (DFD)", 2)
    add_table(
        doc,
        ["Step", "Data Flow"],
        [
            ["1", "User selects a target role and uploads a PDF or DOCX resume."],
            ["2", "Frontend sends multipart form data to POST /analyze."],
            ["3", "FastAPI validates the file extension and saves the uploaded file in uploads."],
            ["4", "Utility functions extract plain text using pdfplumber or python-docx."],
            ["5", "AdvancedAnalyzer extracts sections and resolves role benchmark data."],
            ["6", "TF-IDF vectorization and cosine similarity calculate semantic match percentage."],
            ["7", "The analyzer prepares score, keywords, formatting report, and feedback."],
            ["8", "Frontend renders the JSON response in score cards, lists, tags, and charts."],
            ["9", "User can ask the chat widget about score, skills, formatting, or suggestions."],
        ],
        widths=[1000, 8200],
    )
    add_caption(doc, "Figure 3.2: Data flow of resume analysis")
    add_heading(doc, "3.3.2 UML Class Diagram", 2)
    add_table(
        doc,
        ["Class/Entity", "Important Members", "Responsibility"],
        [
            ["FastAPI app", "upload_resume, analyze_resume, chat_with_bot", "Exposes web API endpoints and serves frontend files."],
            ["AdvancedAnalyzer", "vectorizer, analyze_advanced, get_keyword_density, check_formatting, rewrite_bullets, generate_chat_response", "Performs scoring, matching, keyword analysis, formatting analysis, and chatbot response generation."],
            ["ChatRequest", "message, context", "Defines request structure for chat endpoint."],
            ["Role Data", "core_skills, tools, description_keywords", "Represents job role benchmark data loaded from roles.json."],
        ],
        widths=[2200, 3500, 3500],
    )
    add_caption(doc, "Figure 3.3: Logical class/entity design")
    add_heading(doc, "3.4 Database Design", 2)
    add_body(doc, "A conventional database is not implemented in the current version. The role benchmark database is represented as a JSON document. This design keeps the application simple and transparent for academic review.")
    add_table(
        doc,
        ["Data Object", "Fields", "Usage"],
        [
            ["Role benchmark", "core_skills, tools, description_keywords", "Used as target role data during semantic matching and missing keyword detection."],
            ["Analysis result", "overall_score, language, match_percentage, section_scores, keyword_density, missing_keywords, overused_keywords, formatting_report, feedback, role_context", "Returned by /analyze and displayed by the frontend."],
            ["History item", "score, role, date", "Stored in localStorage to show last five analyses."],
        ],
        widths=[2200, 4000, 3000],
    )
    add_heading(doc, "3.5 Module Description", 2)
    module_rows = [
        ["Resume Upload Module", "Accepts PDF/DOCX files through drag-and-drop or file browser."],
        ["Role Selection Module", "Provides built-in roles and custom role input."],
        ["Text Extraction Module", "Extracts text from uploaded files using PDF and DOCX parsing libraries."],
        ["NLP Analysis Module", "Extracts sections, computes keyword density, detects language, and prepares analysis data."],
        ["Semantic Matching Module", "Uses TF-IDF and cosine similarity to compare resume text with role or job description target text."],
        ["Feedback Module", "Generates strengths, weaknesses, formatting issues, and bullet rewrite suggestions."],
        ["Visualization Module", "Displays scores, radar chart, keyword tags, and analysis history."],
        ["Career Coach Module", "Generates rule-based chat responses using the latest analysis context."],
    ]
    add_table(doc, ["Module", "Description"], module_rows, widths=[2600, 6600])
    add_heading(doc, "3.6 User Interface Design", 2)
    add_body(doc, "The interface follows a dark glassmorphic visual style named Midnight Pro in the existing documentation. It includes a sticky navigation bar, hero section, upload container, job role selector, optional job description box, results dashboard, tips section, loading overlay, and floating chat widget.")
    add_screenshot(doc, "04_analysis_dashboard.png", "Figure 3.4: Result dashboard design after resume analysis")
    for item in [
        "Login/Signup screens are not implemented in the current version.",
        "The main screen combines role selection, resume upload, job description input, and analyze action.",
        "The result screen shows ATS score, language badge, radar chart, strengths, weaknesses, suggestions, missing keywords, formatting report, and analysis history.",
        "The chat widget appears after analysis and uses the analysis response as context.",
    ]:
        add_bullet(doc, item)
    add_heading(doc, "3.7 Summary", 2)
    add_body(doc, "The design provides a clear separation between user interface, API handling, utility functions, analysis logic, and role data. This makes the project understandable, maintainable, and suitable for future extension with authentication, database persistence, or real LLM integration.")
    doc.add_page_break()


def chapter_4(doc):
    add_heading(doc, "4. SOFTWARE MODEL", 1)
    add_heading(doc, "4.1 Introduction", 2)
    add_body(doc, "A software development model provides structure to the planning, design, implementation, testing, and maintenance of a project. For the AI Resume Analyzer, the Agile model is appropriate because features can be designed, implemented, tested, and improved in short iterations.")
    add_heading(doc, "4.2 Agile Software Development Model", 2)
    add_body(doc, "The Agile model focuses on incremental development and continuous feedback. In this project, the upload workflow, backend API, text extraction, role matching, scoring, frontend dashboard, and chat interface can each be treated as separate increments.")
    add_heading(doc, "4.3 Phases of Agile Model", 2)
    phases = [
        ("Requirement Analysis", "Identify the need for automated resume analysis, supported file formats, scoring requirements, and user-facing feedback."),
        ("Planning", "Choose FastAPI, Python NLP libraries, static frontend technology, file-based role data, and Render deployment."),
        ("Design", "Design API endpoints, frontend workflow, analysis response schema, role data structure, and dashboard sections."),
        ("Implementation", "Develop backend routes, utility functions, analyzer methods, frontend event handlers, result rendering, and chat logic."),
        ("Testing", "Validate file uploads, response fields, role selection, job description matching, dashboard rendering, and error conditions."),
        ("Deployment", "Prepare build.sh and render.yaml so the application can be hosted as a Python web service."),
        ("Maintenance", "Improve parsing accuracy, add persistent storage, integrate real LLM APIs, and strengthen security controls."),
    ]
    add_table(doc, ["Phase", "Application in Project"], phases, widths=[2400, 6800])
    add_heading(doc, "4.4 Advantages of Agile Model", 2)
    for item in [
        "Allows quick implementation of individual features.",
        "Supports iterative improvement of scoring and feedback logic.",
        "Makes frontend and backend development easier to coordinate.",
        "Allows feedback from users or evaluators to be included in later versions.",
    ]:
        add_bullet(doc, item)
    add_heading(doc, "4.5 Limitations of Agile Model", 2)
    for item in [
        "Requires regular review to prevent scope changes from becoming uncontrolled.",
        "Documentation can lag behind implementation if not maintained carefully.",
        "Testing must be repeated after each change to avoid regression.",
    ]:
        add_bullet(doc, item)
    add_heading(doc, "4.6 Expected Outcome", 2)
    add_body(doc, "The expected outcome is a working web application that accepts resumes, analyzes them against job roles and optional descriptions, provides a score and feedback, and presents results through an interactive dashboard.")
    add_screenshot(doc, "05_tips_and_history.png", "Figure 4.1: Iterative user feedback screen supporting continuous resume improvement")
    add_heading(doc, "4.7 Summary", 2)
    add_body(doc, "The Agile model suits the project because the system can be improved module by module. Future enhancements such as login, persistent storage, advanced parsing, and LLM integration can be added as new iterations.")
    doc.add_page_break()


def chapter_5(doc):
    add_heading(doc, "5. TOOLS AND TECHNOLOGIES", 1)
    add_heading(doc, "5.1 Introduction", 2)
    add_body(doc, "This chapter describes the tools and technologies actually used in the AI Resume Analyzer codebase. The stack is based on Python, FastAPI, NLP libraries, static frontend technologies, and deployment configuration for Render.")
    add_heading(doc, "5.2 Frontend Technologies", 2)
    add_table(
        doc,
        ["Technology", "Purpose"],
        [
            ["HTML5", "Defines page structure, upload form, dashboard, tips section, and chat widget."],
            ["CSS3", "Implements the dark glassmorphic theme, layout, animations, and responsive design."],
            ["Vanilla JavaScript", "Handles file selection, API calls, result rendering, chart rendering, localStorage, and chat events."],
            ["Chart.js", "Renders the radar chart showing resume score distribution."],
            ["Google Fonts - Outfit", "Provides modern frontend typography."],
        ],
        widths=[2600, 6600],
    )
    add_screenshot(doc, "04_analysis_dashboard.png", "Figure 5.1: Frontend visualization produced using JavaScript and Chart.js")
    add_heading(doc, "5.3 Backend Technologies", 2)
    add_table(
        doc,
        ["Technology", "Purpose"],
        [
            ["Python", "Primary backend programming language."],
            ["FastAPI", "Web framework for API routes, upload handling, and static file serving."],
            ["Uvicorn", "ASGI server used to run the FastAPI application."],
            ["Pydantic", "Defines request structure for the chat API through FastAPI model validation."],
            ["python-multipart", "Supports multipart form uploads for resume files."],
        ],
        widths=[2600, 6600],
    )
    add_heading(doc, "5.4 Database/Storage Technologies", 2)
    add_body(doc, "The current version does not use MongoDB, MySQL, PostgreSQL, or another persistent database. Storage is handled through JSON files, a local uploads directory, artifacts directory, and browser localStorage.")
    add_heading(doc, "5.5 Authentication/Security Technologies", 2)
    add_body(doc, "User authentication is not implemented in the current codebase. Security-related behavior includes basic file extension validation for PDF and DOCX uploads and CORS configuration. The CORS configuration currently allows all origins, which is convenient for development but should be restricted in production.")
    add_heading(doc, "5.6 AI/ML/NLP Technologies", 2)
    add_table(
        doc,
        ["Technology", "Purpose"],
        [
            ["spaCy", "Used for NLP processing and custom role keyword extraction when the model is installed."],
            ["scikit-learn", "Provides TfidfVectorizer and cosine similarity for semantic role/job description matching."],
            ["langdetect", "Detects resume language as English, Hindi, Other, or Unknown."],
            ["pdfplumber", "Extracts text from PDF resumes."],
            ["python-docx", "Extracts text from DOCX resumes."],
        ],
        widths=[2600, 6600],
    )
    add_heading(doc, "5.7 API Integration", 2)
    add_body(doc, "The project exposes local API endpoints through FastAPI. It does not currently integrate with OpenAI, Gemini, job portals, or external recruitment APIs. The frontend calls backend endpoints through relative paths such as /analyze and /chat.")
    add_table(
        doc,
        ["Method", "Endpoint", "Purpose"],
        [
            ["POST", "/upload-resume", "Uploads and extracts resume text without full analysis."],
            ["POST", "/analyze", "Performs full resume analysis and returns structured JSON feedback."],
            ["POST", "/chat", "Generates a rule-based career coach response using analysis context."],
            ["GET", "/", "Serves the static frontend application."],
        ],
        widths=[1400, 2600, 5200],
    )
    add_heading(doc, "5.8 Development Tools", 2)
    for item in [
        "Visual Studio Code or another code editor can be used for development.",
        "Git and GitHub are used for version control according to the README and contributing guide.",
        "Postman or a browser can be used for API testing.",
        "Render is configured as a deployment target through render.yaml.",
    ]:
        add_bullet(doc, item)
    add_heading(doc, "5.9 Testing Tools", 2)
    add_body(doc, "No automated test suite is present in the inspected codebase. Testing is currently expected to be manual through the browser interface and API requests. Future versions should add pytest tests for backend analysis functions and browser tests for frontend workflows.")
    add_heading(doc, "5.10 Summary", 2)
    add_body(doc, "The technology stack is lightweight and suitable for academic demonstration. It avoids complex build tools and uses standard Python and web technologies to deliver the resume analysis workflow.")
    doc.add_page_break()


def chapter_6(doc):
    add_heading(doc, "6. IMPLEMENTATION", 1)
    add_heading(doc, "6.1 Introduction", 2)
    add_body(doc, "Implementation describes how the designed system is converted into working software. The AI Resume Analyzer implementation is divided into frontend files, backend routes, utility functions, analyzer logic, role data, deployment configuration, and supporting scripts.")
    add_heading(doc, "6.2 System Environment", 2)
    add_heading(doc, "6.2.1 Frontend Environment", 3)
    add_body(doc, "The frontend is built as a static application inside the frontend directory. It contains index.html, style.css, and script.js. FastAPI serves these files through StaticFiles mounted at the root route.")
    add_heading(doc, "6.2.2 Backend Environment", 3)
    add_body(doc, "The backend is implemented in Python using FastAPI. The main application file is backend/main.py. It configures CORS, creates the analyzer instance, defines API endpoints, and mounts the frontend.")
    add_heading(doc, "6.2.3 Storage Environment", 3)
    add_body(doc, "The project uses backend/roles.json as a role data source. Uploaded files are saved to the uploads directory. Browser localStorage stores recent analysis history.")
    add_heading(doc, "6.2.4 NLP/ML Integration Environment", 3)
    add_body(doc, "The analyzer uses TfidfVectorizer with unigram and bigram support. Cosine similarity compares the resume text against target role text or job description text. spaCy is used when available and falls back gracefully when the language model is missing.")
    add_heading(doc, "6.2.5 Development Tools", 3)
    add_body(doc, "The application can be run locally with python -m uvicorn backend.main:app --reload. Dependencies are installed from requirements.txt, and the spaCy English model can be downloaded with python -m spacy download en_core_web_sm.")
    add_heading(doc, "6.3 Implementation Process", 2)
    implementation_steps = [
        ["Environment Setup", "Install Python dependencies and download the spaCy language model."],
        ["Backend Setup", "Create FastAPI app, configure CORS, create upload directory, and instantiate AdvancedAnalyzer."],
        ["File Upload", "Accept PDF/DOCX files using UploadFile and save them into uploads."],
        ["Text Extraction", "Use pdfplumber for PDF and python-docx for DOCX extraction."],
        ["Section Parsing", "Use heuristic section headers to identify skills, experience, projects, and education."],
        ["Role Matching", "Load job roles from roles.json and create target text from role keywords or job description."],
        ["Semantic Scoring", "Apply TF-IDF vectorization and cosine similarity to compute match percentage."],
        ["Feedback Generation", "Generate section scores, missing keywords, overused keywords, formatting issues, strengths, weaknesses, and suggestions."],
        ["Dashboard Rendering", "Use JavaScript to render score, lists, radar chart, keyword tags, and history."],
        ["Chat Response", "Use rule-based intent matching to answer questions about score, skills, formatting, and improvement."],
    ]
    add_table(doc, ["Implementation Step", "Description"], implementation_steps, widths=[2600, 6600])
    add_screenshot(doc, "03_upload_ready.png", "Figure 6.1: Implementation state showing selected file, job description input, and analyze action")
    add_screenshot(doc, "04_analysis_dashboard.png", "Figure 6.2: Implemented analysis workflow displayed in the browser")
    add_heading(doc, "6.4 Testing and Debugging", 2)
    add_body(doc, "Manual testing can be performed by uploading valid PDF and DOCX files, selecting different roles, entering job descriptions, and verifying the returned JSON and dashboard output. Invalid file types should return an HTTP 400 error.")
    add_table(
        doc,
        ["Test Area", "Expected Result"],
        [
            ["Valid PDF upload", "Resume text is extracted and analyzed."],
            ["Valid DOCX upload", "Resume text is extracted and analyzed."],
            ["Invalid file upload", "API returns a 400 error."],
            ["Role selection", "Missing keywords are based on selected role data."],
            ["Optional job description", "Match percentage is calculated against the pasted description."],
            ["Chat widget", "Chat response reflects score, skills, formatting, or suggestions."],
        ],
        widths=[2600, 6600],
    )
    add_heading(doc, "6.5 Deployment", 2)
    add_body(doc, "The repository contains render.yaml and build.sh for deployment on Render. The build script installs dependencies, downloads the spaCy model, and creates uploads and artifacts directories. The start command runs uvicorn backend.main:app on the assigned Render port.")
    add_heading(doc, "6.6 Challenges Faced", 2)
    for item in [
        "Extracted resume text can vary depending on PDF structure and formatting.",
        "Section extraction depends on recognizable headers and may miss unusual resume formats.",
        "Semantic matching with TF-IDF is lightweight but less context-aware than modern transformer or LLM-based matching.",
        "The chatbot is rule-based and does not generate deeply contextual advice like a real LLM.",
        "The current system does not persist user accounts or server-side analysis history.",
    ]:
        add_bullet(doc, item)
    add_heading(doc, "6.7 Solutions Implemented", 2)
    for item in [
        "Support for both PDF and DOCX input formats was implemented.",
        "Role-specific JSON data was added to improve matching beyond generic scoring.",
        "Fallback behavior was added when the spaCy language model is not installed.",
        "The frontend renders analysis results visually to make feedback easier to understand.",
        "Render deployment files were added to simplify hosting.",
    ]:
        add_bullet(doc, item)
    add_heading(doc, "6.8 Summary", 2)
    add_body(doc, "The implementation successfully combines document parsing, NLP-based analysis, scoring, feedback generation, and frontend visualization into one working application.")
    doc.add_page_break()


def chapter_7(doc):
    add_heading(doc, "7. RESULTS", 1)
    add_heading(doc, "7.1 Introduction", 2)
    add_body(doc, "The result of the project is a working web application that analyzes resumes and presents improvement guidance to users. The results are based on implemented behavior observed from the codebase and documented application workflow.")
    add_heading(doc, "7.2 Overview of System Outcomes", 2)
    for item in [
        "The user can upload a PDF or DOCX resume.",
        "The user can select from 16+ job roles or enter a custom role.",
        "The user can paste an optional job description for better matching.",
        "The backend returns an overall score, match percentage, language, section scores, keyword density, missing keywords, formatting report, and feedback.",
        "The frontend displays the result through score cards, lists, tags, radar chart, and analysis history.",
        "The chat widget can answer common questions using the latest analysis context.",
    ]:
        add_bullet(doc, item)
    add_screenshot(doc, "04_analysis_dashboard.png", "Figure 7.1: Actual analysis result showing score, keyword gaps, and formatting output")
    add_heading(doc, "7.3 Functional Testing Results", 2)
    add_table(
        doc,
        ["Function", "Input", "Expected Output", "Status"],
        [
            ["Resume upload", "PDF/DOCX file", "File accepted and sent for analysis", "Implemented"],
            ["Invalid file validation", "Unsupported file extension", "HTTP 400 error", "Implemented"],
            ["Role analysis", "Selected predefined role", "Role-specific missing keywords", "Implemented"],
            ["Custom role analysis", "Other role plus custom text", "Keywords generated from custom role/JD", "Implemented"],
            ["Score visualization", "Analysis JSON", "Score ring and radar chart", "Implemented"],
            ["History", "Completed analysis", "Last five scores saved in browser", "Implemented"],
            ["Chat", "Question plus context", "Rule-based answer", "Implemented"],
        ],
        widths=[2000, 2500, 3300, 1400],
    )
    add_heading(doc, "7.3.1 Resume Processing Module", 3)
    add_body(doc, "The resume processing module accepts PDF and DOCX files. PDF extraction uses pdfplumber, while DOCX extraction uses python-docx. The extracted text is passed into the analyzer for section detection and scoring.")
    add_heading(doc, "7.3.2 Role Matching Module", 3)
    add_body(doc, "The role matching module uses role data from backend/roles.json. For predefined roles, core skills and description keywords are combined into target text. For custom roles, spaCy or basic splitting is used to derive role keywords, and job description keywords can also be included.")
    add_heading(doc, "7.3.3 Analysis and Scoring Module", 3)
    add_body(doc, "The scoring module assigns points for skills, experience, projects, and education sections. It adds a semantic match bonus derived from cosine similarity and caps the total score at 100.")
    add_heading(doc, "7.3.4 Dashboard Module", 3)
    add_body(doc, "The dashboard displays the numeric ATS score, language badge, radar chart, strengths, weaknesses, suggestions, missing keywords, formatting issues, and history. The interface becomes visible after a successful analysis.")
    add_heading(doc, "7.4 AI/ML/NLP Performance Evaluation", 2)
    add_body(doc, "The system uses lightweight NLP and machine learning methods. TF-IDF and cosine similarity are fast and suitable for demonstration. However, these methods are less semantically rich than transformer embeddings or LLM-based analysis. The current system is best understood as NLP-assisted resume scoring rather than a fully generative AI system.")
    add_heading(doc, "7.5 User Interface Evaluation", 2)
    add_heading(doc, "7.5.1 Usability Testing", 3)
    add_body(doc, "The workflow is designed to be easy to follow. The role selector, drag-and-drop upload zone, optional job description area, and analyze button appear in a single central upload container.")
    add_heading(doc, "7.5.2 Responsiveness Testing", 3)
    add_body(doc, "The CSS uses grid layouts, flexible containers, and responsive patterns. Final responsiveness should be verified in browser testing on desktop and mobile screen sizes.")
    add_heading(doc, "7.5.3 Performance Testing", 3)
    add_body(doc, "The analysis should be fast for typical resumes because TF-IDF vectorization and cosine similarity operate on a small number of text documents. Larger files and complex PDFs may increase processing time.")
    add_heading(doc, "7.6 System Performance Evaluation", 2)
    add_body(doc, "The backend performs analysis in a single request-response cycle. Since there is no database write operation and no external LLM API call, latency is mainly affected by file extraction and NLP processing.")
    add_heading(doc, "7.7 Comparative Analysis", 2)
    add_table(
        doc,
        ["Aspect", "Manual/Existing Approach", "Proposed System"],
        [
            ["Review speed", "Slow and dependent on human reviewer availability.", "Provides immediate automated feedback."],
            ["Role matching", "Often generic and subjective.", "Uses role-specific benchmark keywords and optional JD text."],
            ["Consistency", "Varies by reviewer.", "Uses consistent scoring logic for every resume."],
            ["Visualization", "Usually absent.", "Provides score ring, radar chart, tags, and history."],
            ["Limitations", "Can include human judgment and context.", "Limited by parsing quality and lightweight NLP methods."],
        ],
        widths=[2200, 3500, 3500],
    )
    add_heading(doc, "7.8 Discussion", 2)
    add_body(doc, "The system demonstrates how NLP techniques can support job seekers by converting resume content into measurable feedback. It is especially useful for educational demonstration because the scoring algorithm is understandable and can be improved in future iterations.")
    add_heading(doc, "7.9 Screenshots and Output Overview", 2)
    add_screenshot(doc, "06_career_coach.png", "Figure 7.2: Career Coach response generated from the latest analysis context")
    for item in [
        "Main upload page with role selector and resume upload box.",
        "Analysis dashboard showing ATS score and language badge.",
        "Feedback cards showing strengths, weaknesses, and suggestions.",
        "Keyword gap tags and formatting report.",
        "AI Career Coach chat interface.",
    ]:
        add_bullet(doc, item)
    add_heading(doc, "7.10 Summary", 2)
    add_body(doc, "The results show that the project achieves its main goal of providing automated resume analysis, score visualization, keyword feedback, and improvement suggestions.")
    doc.add_page_break()


def chapter_8(doc):
    add_heading(doc, "8. SNAPSHOTS", 1)
    add_heading(doc, "8.1 Introduction", 2)
    add_body(doc, "This chapter presents screenshots captured from the running AI Resume Analyzer application. The screenshots demonstrate the main interface, custom role workflow, resume upload state, analysis dashboard, improvement history, career coach, and mobile responsiveness.")
    snapshots = [
        ("8.2 Main Interface", "01_main_interface.png", "Figure 8.1: Main interface showing project heading, role selector, upload container, and job description box"),
        ("8.3 Custom Role Input", "02_custom_role_input.png", "Figure 8.2: Custom role option showing the additional role input field"),
        ("8.4 Resume Upload and Job Description", "03_upload_ready.png", "Figure 8.3: Resume selected with job description entered before analysis"),
        ("8.5 Analysis Result Dashboard", "04_analysis_dashboard.png", "Figure 8.4: ATS compatibility score, radar chart, keyword gaps, and formatting output"),
        ("8.6 Improvement Tips and History", "05_tips_and_history.png", "Figure 8.5: Analysis history and resume improvement tips after processing"),
        ("8.7 Career Coach Chat", "06_career_coach.png", "Figure 8.6: AI Career Coach chat response based on missing skills"),
        ("8.8 Mobile Result View", "07_mobile_results.png", "Figure 8.7: Mobile result and chat view showing responsive behavior"),
        ("8.9 Mobile Main Interface", "08_mobile_main.png", "Figure 8.8: Mobile main interface showing compact layout behavior"),
    ]
    for heading, filename, caption in snapshots:
        add_heading(doc, heading, 2)
        add_screenshot(doc, filename, caption)
    add_heading(doc, "8.10 Summary", 2)
    add_body(doc, "The snapshots will visually demonstrate the main workflow of the application from resume upload to result interpretation.")
    doc.add_page_break()


def chapter_9_to_12(doc):
    add_heading(doc, "9. CONCLUSION", 1)
    add_heading(doc, "9.1 Conclusion", 2)
    add_body(doc, "The AI Resume Analyzer successfully demonstrates a web-based approach to automated resume evaluation. It accepts PDF and DOCX resumes, extracts text, compares resume content with role-specific benchmarks or job descriptions, calculates an ATS compatibility score, identifies missing keywords, checks formatting, and presents recommendations through an interactive dashboard.")
    add_body(doc, "The project is useful for students and job seekers who want quick feedback before applying for jobs. It also provides a strong academic example of combining frontend development, API design, document processing, NLP, machine learning, and deployment preparation.")
    add_screenshot(doc, "06_career_coach.png", "Figure 9.1: Final improvement guidance available through the Career Coach interface")
    doc.add_page_break()
    add_heading(doc, "10. LIMITATIONS", 1)
    add_screenshot(doc, "04_analysis_dashboard.png", "Figure 10.1: Formatting and keyword warnings that motivate future improvement")
    limitations = [
        "The project does not currently include user authentication or multi-user accounts.",
        "There is no persistent server-side database for storing user resumes or analysis history.",
        "The chatbot is rule-based and does not use a real LLM API.",
        "The section extraction method depends on standard resume headings and may fail for unusual formats.",
        "TF-IDF similarity is lightweight and may not understand deep semantic meaning.",
        "PDF extraction quality depends on the structure of the uploaded PDF.",
        "CORS currently allows all origins and should be restricted for production.",
        "Automated tests are not present in the inspected codebase.",
    ]
    for item in limitations:
        add_numbered(doc, item)
    doc.add_page_break()
    add_heading(doc, "11. FUTURE ENHANCEMENT", 1)
    add_screenshot(doc, "05_tips_and_history.png", "Figure 11.1: User improvement workflow that can be extended with richer analytics and saved history")
    enhancements = [
        "Add user authentication with secure password hashing and account-based history.",
        "Introduce a persistent database such as PostgreSQL or MongoDB for saved analyses.",
        "Integrate a real LLM API for richer resume suggestions and conversational coaching.",
        "Use transformer embeddings for deeper semantic job description matching.",
        "Add resume improvement export features such as downloadable PDF/DOCX reports.",
        "Improve section extraction with layout-aware parsing and more robust heading detection.",
        "Add admin tools to manage role benchmarks and skill databases.",
        "Restrict CORS, validate file contents more strongly, and add malware-safe upload handling.",
        "Add automated backend and frontend tests.",
        "Deploy the system with production monitoring and logging.",
    ]
    for item in enhancements:
        add_numbered(doc, item)
    doc.add_page_break()
    add_heading(doc, "12. BIBLIOGRAPHY", 1)
    references = [
        "FastAPI Official Documentation - https://fastapi.tiangolo.com/",
        "Uvicorn Official Documentation - https://www.uvicorn.org/",
        "spaCy Official Documentation - https://spacy.io/usage",
        "scikit-learn Documentation - https://scikit-learn.org/stable/",
        "pdfplumber Project Documentation - https://github.com/jsvine/pdfplumber",
        "python-docx Documentation - https://python-docx.readthedocs.io/",
        "Chart.js Documentation - https://www.chartjs.org/docs/latest/",
        "Render Blueprint Documentation - https://render.com/docs/blueprint-spec",
        "MDN Web Docs for HTML, CSS, and JavaScript - https://developer.mozilla.org/",
        "Project source files: backend/main.py, backend/model.py, backend/utils.py, backend/roles.json, frontend/index.html, frontend/style.css, frontend/script.js, requirements.txt, render.yaml, build.sh.",
    ]
    for ref in references:
        add_numbered(doc, ref)


def build_document():
    OUT_DIR.mkdir(exist_ok=True)
    doc = Document()
    configure_document(doc)
    cover_page(doc)
    certificate_page(doc)
    acknowledgement_page(doc)
    contribution_page(doc)
    index_page(doc)

    body_section = doc.add_section(WD_SECTION_START.NEW_PAGE)
    body_section.page_width = Inches(8.27)
    body_section.page_height = Inches(11.69)
    body_section.top_margin = Inches(1)
    body_section.bottom_margin = Inches(1)
    body_section.left_margin = Inches(1)
    body_section.right_margin = Inches(1)
    restart_page_numbering(body_section, start=1)
    footer = body_section.footer
    footer.is_linked_to_previous = False
    if footer.paragraphs:
        add_page_number(footer.paragraphs[0])
    else:
        add_page_number(footer.add_paragraph())

    chapter_1(doc)
    chapter_2(doc)
    chapter_3(doc)
    chapter_4(doc)
    chapter_5(doc)
    chapter_6(doc)
    chapter_7(doc)
    chapter_8(doc)
    chapter_9_to_12(doc)

    doc.save(OUT_FILE)
    print(OUT_FILE)


if __name__ == "__main__":
    build_document()
