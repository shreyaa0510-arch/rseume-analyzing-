from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse
import re


ROOT = Path(__file__).resolve().parents[1]
OUT_DIR = ROOT / "artifacts" / "report_screenshots"
OUT_DIR.mkdir(parents=True, exist_ok=True)


class ScreenshotSink(BaseHTTPRequestHandler):
    def do_POST(self):
        parsed = urlparse(self.path)
        query = parse_qs(parsed.query)
        raw_name = query.get("name", ["screenshot.png"])[0]
        safe_name = re.sub(r"[^A-Za-z0-9_.-]", "_", raw_name)
        if not safe_name.lower().endswith(".png"):
            safe_name += ".png"

        length = int(self.headers.get("Content-Length", "0"))
        data = self.rfile.read(length)
        (OUT_DIR / safe_name).write_bytes(data)

        self.send_response(200)
        self.end_headers()
        self.wfile.write(str(OUT_DIR / safe_name).encode("utf-8"))

    def log_message(self, format, *args):
        return


if __name__ == "__main__":
    server = HTTPServer(("127.0.0.1", 8765), ScreenshotSink)
    print("screenshot sink listening on http://127.0.0.1:8765")
    server.serve_forever()
