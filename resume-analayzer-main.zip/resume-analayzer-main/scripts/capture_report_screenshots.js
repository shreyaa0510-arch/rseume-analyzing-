const { createRequire } = require("node:module");
const fs = require("node:fs/promises");
const path = require("node:path");

const playwrightRequire = createRequire(
  "C:/Users/HP PC/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/.pnpm/playwright@1.60.0/node_modules/playwright/index.js"
);
const { chromium } = playwrightRequire("playwright");

const ROOT = path.resolve(__dirname, "..");
const OUT_DIR = path.join(ROOT, "artifacts", "report_screenshots");
const SAMPLE_RESUME = path.join(ROOT, "artifacts", "sample_resume_for_screenshots.docx");

async function main() {
  await fs.mkdir(OUT_DIR, { recursive: true });

  const browser = await chromium.launch({
    headless: true,
    executablePath: "C:/Program Files/Google/Chrome/Application/chrome.exe",
  });
  const page = await browser.newPage({ viewport: { width: 1366, height: 900 } });

  await page.goto("http://127.0.0.1:8000", { waitUntil: "load" });

  // The app loads Chart.js from a CDN. In offline environments, this stub keeps
  // the result-rendering path alive so screenshots can still be captured.
  await page.evaluate(() => {
    if (!window.Chart) {
      window.Chart = class {
        constructor() {}
        destroy() {}
      };
    }
  });

  await page.screenshot({
    path: path.join(OUT_DIR, "01_main_interface.png"),
    fullPage: false,
  });

  await page.selectOption("#jobRole", "other");
  await page.fill("#customRoleInput", "AI Resume Screening Specialist");
  await page.screenshot({
    path: path.join(OUT_DIR, "02_custom_role_input.png"),
    fullPage: false,
  });

  await page.selectOption("#jobRole", "software_engineer");
  await page.setInputFiles("#fileInput", SAMPLE_RESUME);
  await page.fill(
    "#jobDescription",
    "We are hiring a software engineer with Python, FastAPI, REST API, system design, data structures, algorithms, Git, Docker, and cloud deployment experience."
  );
  await page.screenshot({
    path: path.join(OUT_DIR, "03_upload_ready.png"),
    fullPage: false,
  });

  await page.click("#analyzeBtn");
  await page.waitForSelector("#results:not(.hidden)", { timeout: 20000 });
  await page.waitForTimeout(1200);

  await page.screenshot({
    path: path.join(OUT_DIR, "04_analysis_dashboard.png"),
    fullPage: false,
  });

  await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
  await page.waitForTimeout(500);
  await page.screenshot({
    path: path.join(OUT_DIR, "05_tips_and_history.png"),
    fullPage: false,
  });

  const chatButton = page.locator("#chatToggleBtn");
  if (await chatButton.isVisible()) {
    await chatButton.click();
    await page.fill("#chatInput", "What skills am I missing?");
    await page.click("#chatSendBtn");
    await page.waitForTimeout(1000);
    await page.screenshot({
      path: path.join(OUT_DIR, "06_career_coach.png"),
      fullPage: false,
    });
  }

  await page.setViewportSize({ width: 390, height: 844 });
  await page.waitForTimeout(700);
  await page.screenshot({
    path: path.join(OUT_DIR, "07_mobile_results.png"),
    fullPage: false,
  });

  const mobilePage = await browser.newPage({ viewport: { width: 390, height: 844 } });
  await mobilePage.goto("http://127.0.0.1:8000", { waitUntil: "load" });
  await mobilePage.waitForTimeout(700);
  await mobilePage.screenshot({
    path: path.join(OUT_DIR, "08_mobile_main.png"),
    fullPage: false,
  });
  await mobilePage.close();

  await browser.close();
  console.log(OUT_DIR);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
