from pathlib import Path
from zipfile import ZipFile
from xml.etree import ElementTree as ET
import re
import shutil


ROOT = Path(__file__).resolve().parents[1]
DOCX_PATH = ROOT / "artifacts" / "AI_Resume_Analyzer_Major_Project_Report.docx"
OUT_DIR = ROOT / "artifacts" / "latex_report"
IMG_DIR = OUT_DIR / "images"
TEX_PATH = OUT_DIR / "AI_Resume_Analyzer_Major_Project_Report.tex"

NS = {
    "w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
    "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
    "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
}


def qn(prefix, tag):
    return "{%s}%s" % (NS[prefix], tag)


def latex_escape(text):
    replacements = {
        "\\": r"\textbackslash{}",
        "&": r"\&",
        "%": r"\%",
        "$": r"\$",
        "#": r"\#",
        "_": r"\_",
        "{": r"\{",
        "}": r"\}",
        "~": r"\textasciitilde{}",
        "^": r"\textasciicircum{}",
    }
    return "".join(replacements.get(ch, ch) for ch in text)


def clean_text(text):
    text = text.replace("\u2013", "--")
    text = text.replace("\u2014", "---")
    text = text.replace("\u2018", "'").replace("\u2019", "'")
    text = text.replace("\u201c", "``").replace("\u201d", "''")
    return text


def read_relationships(zip_file):
    rels = {}
    rel_xml = ET.fromstring(zip_file.read("word/_rels/document.xml.rels"))
    for rel in rel_xml:
        rel_id = rel.attrib.get("Id")
        target = rel.attrib.get("Target")
        if rel_id and target:
            rels[rel_id] = target
    return rels


def paragraph_style(paragraph):
    p_style = paragraph.find("w:pPr/w:pStyle", NS)
    if p_style is None:
        return ""
    return p_style.attrib.get(qn("w", "val"), "")


def paragraph_alignment(paragraph):
    jc = paragraph.find("w:pPr/w:jc", NS)
    if jc is None:
        return ""
    return jc.attrib.get(qn("w", "val"), "")


def paragraph_text(paragraph):
    pieces = []
    for node in paragraph.iter():
        if node.tag == qn("w", "t") and node.text:
            pieces.append(node.text)
        elif node.tag == qn("w", "tab"):
            pieces.append(" ")
    return clean_text("".join(pieces)).strip()


def paragraph_images(paragraph, rels):
    images = []
    for blip in paragraph.findall(".//a:blip", NS):
        rel_id = blip.attrib.get(qn("r", "embed"))
        if rel_id and rel_id in rels:
            images.append(rels[rel_id])
    return images


def paragraph_has_page_break(paragraph):
    for br in paragraph.findall(".//w:br", NS):
        if br.attrib.get(qn("w", "type")) == "page":
            return True
    return False


def table_rows(table):
    rows = []
    for tr in table.findall("w:tr", NS):
        row = []
        for tc in tr.findall("w:tc", NS):
            cell_parts = []
            for paragraph in tc.findall("w:p", NS):
                text = paragraph_text(paragraph)
                if text:
                    cell_parts.append(text)
            row.append(" ".join(cell_parts))
        if row:
            rows.append(row)
    return rows


def extract_images(zip_file, rels):
    image_map = {}
    IMG_DIR.mkdir(parents=True, exist_ok=True)
    for rel_target in rels.values():
        if not rel_target.startswith("media/"):
            continue
        src = "word/" + rel_target
        if src not in zip_file.namelist():
            continue
        out_name = Path(rel_target).name
        out_path = IMG_DIR / out_name
        out_path.write_bytes(zip_file.read(src))
        image_map[rel_target] = "images/" + out_name

    # Also copy live screenshot assets with descriptive names for easier manual reuse.
    shot_dir = ROOT / "artifacts" / "report_screenshots"
    if shot_dir.exists():
        for shot in shot_dir.glob("*.png"):
            shutil.copy2(shot, IMG_DIR / shot.name)

    return image_map


def iter_body_blocks(document_root):
    body = document_root.find("w:body", NS)
    for child in list(body):
        if child.tag == qn("w", "p"):
            yield ("p", child)
        elif child.tag == qn("w", "tbl"):
            yield ("tbl", child)


def convert_table(rows):
    if not rows:
        return []
    col_count = max(len(row) for row in rows)
    spec = "|" + "|".join(["X"] * col_count) + "|"
    lines = [
        r"\begin{table}[H]",
        r"\centering",
        r"\small",
        r"\begin{tabularx}{\textwidth}{" + spec + "}",
        r"\hline",
    ]
    for idx, row in enumerate(rows):
        normalized = row + [""] * (col_count - len(row))
        cells = [latex_escape(clean_text(cell)) for cell in normalized]
        lines.append(" & ".join(cells) + r" \\")
        lines.append(r"\hline")
        if idx == 0:
            lines.append(r"\rowcolor{headerblue}")
    lines.extend([r"\end{tabularx}", r"\end{table}", ""])
    return lines


def heading_command(style, text):
    escaped = latex_escape(text)
    if style == "Heading1":
        return r"\section*{" + escaped + "}\n" + r"\addcontentsline{toc}{section}{" + escaped + "}"
    if style == "Heading2":
        return r"\subsection*{" + escaped + "}"
    if style == "Heading3":
        return r"\subsubsection*{" + escaped + "}"
    return None


def convert_blocks(blocks, image_map):
    lines = []
    idx = 0
    while idx < len(blocks):
        block_type, block = blocks[idx]

        if block_type == "tbl":
            lines.extend(convert_table(table_rows(block)))
            idx += 1
            continue

        style = paragraph_style(block)
        align = paragraph_alignment(block)
        text = paragraph_text(block)
        images = paragraph_images(block, {})
        page_break = paragraph_has_page_break(block)

        if images:
            caption = ""
            if idx + 1 < len(blocks) and blocks[idx + 1][0] == "p":
                next_text = paragraph_text(blocks[idx + 1][1])
                if next_text.startswith("Figure "):
                    caption = next_text
                    idx += 1
            for target in images:
                image_path = image_map.get(target)
                if not image_path:
                    continue
                width = "0.45\\textwidth" if Path(image_path).name.startswith(("image")) and "mobile" in caption.lower() else "0.92\\textwidth"
                if "Mobile" in caption:
                    width = "0.45\\textwidth"
                lines.extend(
                    [
                        r"\begin{figure}[H]",
                        r"\centering",
                        r"\includegraphics[width=" + width + "]{" + image_path.replace("\\", "/") + "}",
                    ]
                )
                if caption:
                    lines.append(r"\caption*{" + latex_escape(caption) + "}")
                lines.extend([r"\end{figure}", r"\clearpage", ""])
            idx += 1
            continue

        if text:
            cmd = heading_command(style, text)
            if cmd:
                lines.append(cmd)
                lines.append("")
            elif align == "center":
                lines.append(r"\begin{center}")
                lines.append(r"\textbf{" + latex_escape(text) + "}")
                lines.append(r"\end{center}")
                lines.append("")
            elif text.startswith("Figure "):
                lines.append(r"\textit{" + latex_escape(text) + "}")
                lines.append("")
            else:
                lines.append(latex_escape(text))
                lines.append("")

        if page_break:
            lines.append(r"\clearpage")
            lines.append("")

        idx += 1

    return lines


def add_image_metadata(blocks, rels):
    # xml.etree Elements do not allow arbitrary attributes, so wrap by mapping id().
    image_by_element = {}
    for block_type, block in blocks:
        if block_type == "p":
            image_by_element[id(block)] = paragraph_images(block, rels)
    return image_by_element


def build_latex():
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    with ZipFile(DOCX_PATH) as z:
        rels = read_relationships(z)
        image_map = extract_images(z, rels)
        root = ET.fromstring(z.read("word/document.xml"))
        blocks = list(iter_body_blocks(root))
        image_lookup = add_image_metadata(blocks, rels)

    # Convert with a side lookup because Element objects cannot hold custom attrs.
    patched_blocks = []
    for block_type, block in blocks:
        if block_type == "p":
            patched_blocks.append((block_type, block, image_lookup.get(id(block), [])))
        else:
            patched_blocks.append((block_type, block, []))

    # Use a small adapter so the main conversion loop can stay readable.
    simple_blocks = []
    for block_type, block, images in patched_blocks:
        if images:
            block.attrib["_latex_images"] = "||".join(images)
        simple_blocks.append((block_type, block))

    # ElementTree string attributes are easier to retrieve than monkey-patching.
    original_paragraph_images = paragraph_images

    def patched_paragraph_images(paragraph, _rels):
        stored = paragraph.attrib.get("_latex_images", "")
        return stored.split("||") if stored else original_paragraph_images(paragraph, rels)

    globals()["paragraph_images"] = patched_paragraph_images

    body_lines = convert_blocks(simple_blocks, image_map)

    preamble = [
        r"\documentclass[12pt,a4paper]{article}",
        r"\usepackage[margin=1in]{geometry}",
        r"\usepackage{graphicx}",
        r"\usepackage{float}",
        r"\usepackage{tabularx}",
        r"\usepackage[table]{xcolor}",
        r"\usepackage{array}",
        r"\usepackage{setspace}",
        r"\usepackage{hyperref}",
        r"\usepackage{titlesec}",
        r"\usepackage{caption}",
        r"\definecolor{headingblue}{HTML}{1F4E79}",
        r"\definecolor{headerblue}{HTML}{D9EAF7}",
        r"\titleformat{\section}{\normalfont\Large\bfseries\color{headingblue}}{}{0em}{}",
        r"\titleformat{\subsection}{\normalfont\large\bfseries\color{headingblue}}{}{0em}{}",
        r"\titleformat{\subsubsection}{\normalfont\normalsize\bfseries\color{headingblue}}{}{0em}{}",
        r"\setstretch{1.15}",
        r"\hypersetup{colorlinks=true, linkcolor=headingblue, urlcolor=headingblue}",
        r"\begin{document}",
        "",
    ]
    ending = [r"\end{document}", ""]
    TEX_PATH.write_text("\n".join(preamble + body_lines + ending), encoding="utf-8")
    print(TEX_PATH)


if __name__ == "__main__":
    build_latex()
